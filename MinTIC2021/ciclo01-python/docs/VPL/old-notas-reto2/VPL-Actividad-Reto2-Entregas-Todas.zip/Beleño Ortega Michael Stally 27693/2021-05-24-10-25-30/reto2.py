# FUNCION PARA VALIDAR QUE SE HAYA INGRESADO UN NUMERO DECIMAL
def validar_decimal(mensaje):
    contador = 0  # VARIABLE QUE NOS AYUDARÁ A SABER CUANTAS VECES SE HA EQUIVOCADO EL CLIENTE
    puntos = 0  # VARIABLE QUE NOS AYUDARÁ A SABER CUANTAS VECES SE HA EQUIVOCADO EL CLIENTE
    digitos = 0  # VARIABLE QUE NOS AYUDARÁ A SABER CUANTOS DIGITOS HAY EN LA ENTRADA DE DATOS

    # CICLO PARA PEDIR UN NUMERO
    while True:
        # SI EL CLIENTE SE HA EQUIVOCADO MÁS DE UNA VEZ, ENTONCES MOSTRARÁ MENSAJE DE ERROR
        if contador > 0:
            temporal = valida_vacio(mensaje, "Debe ingresar un número o decimal(Con punto). ")

        # SI ES LA PRIMERA VEZ QUE VA A INGRESAR UN VALOR, ENTONCES NO MOSTRARÁ MENSAJE DE ERROR
        else:
            temporal = valida_vacio(mensaje, "")

        contador += 1  # AUMENTARÁ CADA VEZ QUE EL CICLO SE REPITA (NO SE INGRESO UN NUMERO)

        # CICLO PARA RECORRER TODOS LOS CARACTERES DE LA ENTRADA DE DATOS
        for caracter in temporal:

            # VALIDAMOS SI INGRESÓ UN NUMERO
            if caracter.isdigit():
                digitos += 1

            # EN CASO DE NO INGRESAR UN NÚMERO PUEDE INGRESAR SOLO UN PUNTO "."
            elif caracter == "." and puntos == 0:
                puntos += 1

        # OBTENEMOS EL TOTAL DE CARACTERES DE LA CADENA
        numero_caracteres = len(temporal)

        # VALIDAMOS SI EL NUMERO DE CARACTERES VALIDOS ES IGUAL AL NUMERO DE CARACTERES DE LA ENTRADA DE DATO
        if (digitos + puntos) == numero_caracteres:
            break

        # EN CASO DE QUE AMBAS LONGITUDES NO SEAN IGUALES, REINICIARÁ LAS VARIABLES Y VOLVERÁ A PEDIR EL DATO
        else:
            digitos = 0
            puntos = 0

    return float(temporal)


# FUNCIÓN PARA VALIDAR QUE SOLO SE INGRESEN NÚMEROS
def validar_numero(mensaje):
    contador = 0  # VARIABLE QUE NOS AYUDARÁ A SABER CUANTAS VECES SE HA EQUIVOCADO EL CLIENTE

    # CICLO PARA PEDIR UN NUMERO
    while True:
        # SI EL CLIENTE SE HA EQUIVOCADO MÁS DE UNA VEZ, ENTONCES MOSTRARÁ MENSAJE DE ERROR
        if contador > 0:
            temporal = valida_vacio(mensaje, "Debe ingresar un número. ")

        # SI ES LA PRIMERA VEZ QUE VA A INGRESAR UN VALOR, ENTONCES NO MOSTRARÁ MENSAJE DE ERROR
        else:
            temporal = valida_vacio(mensaje, "")

        contador += 1  # AUMENTARÁ CADA VEZ QUE EL CICLO SE REPITA (NO SE INGRESO UN NUMERO)

        # POR ULTIMO VALIDAMOS QUE EL VALOR INGRESADO SEA UN NÚMERO DIFERENTE DE UN SOLO 0, DEVOLVERA EL NUMERO
        if temporal.isdigit() and temporal != "0":
            break
    return int(temporal)


# FUNCION PARA VALIDAR ENTRADAS VACIAS
def valida_vacio(mensaje, error):
    temporal = input(error + mensaje)  # PRIMERO PEDIREMOS AL CLIENTE QUE INGRESE UN VALOR

    # CICLO QUE SE REPETIRA HASTA INGRESAR AL MENOS UN VALOR
    while True:

        # SI NO SE INGRESO NADA (PRESIONO ENTER) O LA VARIABLE RECIBIO LA MENOS UN DATO, SALDRÁ DEL CICLO
        if len(temporal) > 0:
            break

        # SI NO INGRESÓ NADA, ENTONCES SE LE VOLVERÁ A PEDIR CON UN MENSAJE DE ERROR
        else:
            temporal = input("Debe ingresar al menos un valor. " + mensaje)

    return str(temporal)


# FUNCIONA PARA SIMULAR UN SWITCH-CASE
def switch_descuento(valor, opcion):
    # EN CASO DE NECESITAR REALIZAR EL DESCUENTO POR EDAD SE VALIDARÁ SEGÚN REQUERIMIENTOS
    if opcion == "Edad":

        # SI ES MAYOR O IGUAL A 15 Y MENOR O IGUAL A 18
        if 15 <= valor <= 18:
            descuento = 25

        # SI ES MAYOR O IGUAL A 19 Y MENOR O IGUAL A 21
        elif 19 <= valor <= 21:
            descuento = 15

        # SI ES MAYOR O IGUAL A 22 Y MENOR O IGUAL A 25
        elif 22 <= valor <= 25:
            descuento = 10

        # SI ES MAYOR A 25 Y MENOR A 15
        else:
            descuento = 0

    # EN CASO DE NECESITAR REALIZAR EL DESCUENTO POR SMLV SE VALIDARÁ SEGÚN REQUERIMIENTOS
    elif opcion == "Smlv":

        # SI ES MENOR O IGUAL A 1
        if valor <= 1:
            descuento = 30

        # SI ES MAYOR A 1 Y MENOR O IGUAL A 2
        elif 1 < valor <= 2:
            descuento = 20

        # SI ES MAYOR A 2 Y MENOR O IGUAL A 3
        elif 2 < valor <= 3:
            descuento = 10

        # SI ES MAYOR A 3 Y MENOR O IGUAL A 4
        elif 3 < valor <= 4:
            descuento = 5

        # SI ES MAYOR A 4
        else:
            descuento = 0

    # EN CASO DE NECESITAR REALIZAR EL DESCUENTO POR NOTA SE VALIDARÁ SEGÚN REQUERIMIENTOS
    else:

        # SI ES MAYOR O IGUAL A 80 Y MENOR A 86
        if 80 <= valor < 86:
            descuento = 30

        # SI ES MAYOR O IGUAL A 86 Y MENOR A 91
        elif 86 <= valor < 91:
            descuento = 35

        # SI ES MAYOR O IGUAL A 91 Y MENOR A 96
        elif 91 <= valor < 96:
            descuento = 40

        # SI ES MAYOR A 96
        elif valor >= 96:
            descuento = 45

        # SI ES MENOR A 80
        else:
            descuento = 0
    return descuento


# PROGRAMA PRINCIPAL ------------------------------------------------------------------
# nombre = valida_vacio("\nPor favor ingrese el NOMBRE del estudiante N° " + str(i + 1) + ": ", "")
# apellido = valida_vacio("Por favor ingrese el APELLIDO del estudiante N° " + str(i + 1) + ": ", "")
edad = validar_numero("Por favor ingrese la EDAD del estudiante N° : ")
nota = validar_numero("Por favor ingrese la NOTA del examén para el estudiante N° : ")
smlv = validar_decimal("Por favor ingrese la cantidad de SMLV familiar del estudiante N° : ")

total = switch_descuento(edad, "Edad") + switch_descuento(smlv, "Smlv") + switch_descuento(nota, "Nota")

print(switch_descuento(edad, "Edad"))
print(switch_descuento(nota, "Nota"))
print(switch_descuento(smlv, "Smlv"))
print(total)
