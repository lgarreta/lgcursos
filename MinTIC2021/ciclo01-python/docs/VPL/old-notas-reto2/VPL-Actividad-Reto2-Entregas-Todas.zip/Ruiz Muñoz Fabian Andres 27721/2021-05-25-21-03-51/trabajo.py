# estudiantes
#print("datos candidato")
#nombre=input("ingresar nombre:  ")
#apellido=input("ingresar apellido: ")
edad     =int(input("ingresar edad "))
puntaje  =int(input("ingresar puntaje de actitud "))
salario  =int(input("ingresar salario "))

if (edad >=15 and edad <=18):
    #print("bono porcentaje 25%")
    poredad=25
    
elif (edad >=19 and edad <=21):
   #print("bono porcentaje 15%")
   poredad=15
    
elif (edad >=22 and edad <=25):
   # print("bono porcetaje 10%")
   poredad=10
elif(edad<14):
    poredad=0
elif(edad >26):
    poredad=0
#print("datos examen de aptitud")


#(puntaje > 0 and puntaje  < 100):
   # nota = calificacion

#print  ("nota errada")
   # nota=0
    
if(puntaje>=0 and puntaje <80):
   # print("sin porcentaje")
    porcentaje=0
    
elif(puntaje >=80 and puntaje <86):
    #print(" auxilio de 30%")
    porcentaje =30

elif(puntaje>=86 and puntaje <91):
    porcentaje =35
    
elif(puntaje >=91 and puntaje <96):
    #print("auxilio 40% ")
    porcentaje =40
    
elif(puntaje>96 and puntaje  <=100):
    #print("auxilio 45% ")
    porcentaje =45
    
#print("datos examen de aptitud")
    
#print("ingreso familiar estudiante")
#ingreso=int(input("ingreso familiar: "))

##if (ingreso >=0 and ingreso <=4):
    #print ("otorgar auxilio")
    #ingresofa = ingreso
##else:
    ##print("no otorgar auxilio")
   # ingresofa= ingreso
    
if (salario <=1):
   # print("otorgar 30%")
    bonofamiliar = 30
    
elif (salario>1 and salario <=2):
    ##print("otorgar 20")
    bonofamiliar = 20
    
elif(salario>2 and salario<=3):
    #print("otargar10")
    bonofamiliar=10
    
elif(salario>3 and salario<=4):
    #print("otorgar5")
    bonofamiliar=5
elif(salario>=5):
    bonofamiliar=0


total=(bonofamiliar+porcentaje+poredad)
    
print= poredad
print= porcentaje
print= bonofamiliar
print= total
##bonos= [ porcentaje, poredad, bonofamiliar ]
##print("bonos")
#print(bonos[:])

###print("nombre completo", nombre, apellido," edad",edad,"años","porcentaje",porcentaje)


#apoyomatricula = porcentaje + poredad + bonofamiliar
#print("Total apoyo matricula", apoyomatricula )










