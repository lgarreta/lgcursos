
edad     =int(input("ingresar edad "))
puntaje  =int(input("ingresar puntaje de actitud "))
salario  =int(input("ingresar salario "))

if (edad >=15 and edad <=18):
    poredad=25
elif (edad >=19 and edad <=21):
   poredad=15
elif (edad >=22 and edad <=25):
   poredad=10
elif(edad<14):
    poredad=0
elif(edad >26):
    poredad=0
    
if(puntaje>=0 and puntaje <80):
    porcentaje=0
elif(puntaje >=80 and puntaje <86):
    porcentaje =30
elif(puntaje>=86 and puntaje <91):
    porcentaje =35
elif(puntaje >=91 and puntaje <96):
    porcentaje =40
elif(puntaje>96 and puntaje  <=100):
    porcentaje =45
    
if (salario <=1):
    bonofamiliar = 30
elif (salario>1 and salario <=2):
    bonofamiliar = 20
elif(salario>2 and salario<=3):
    bonofamiliar=10
elif(salario>3 and salario<=4):
    bonofamiliar=5
elif(salario>=5):
    bonofamiliar=0

total=(bonofamiliar+porcentaje+poredad)
    
print= poredad
print= porcentaje
print= bonofamiliar
print= total