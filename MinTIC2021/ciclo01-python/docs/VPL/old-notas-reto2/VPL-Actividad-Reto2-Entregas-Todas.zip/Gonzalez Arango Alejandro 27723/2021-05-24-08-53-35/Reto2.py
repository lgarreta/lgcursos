# Programa de porcentajes de ayuda para la matricula de la Universidad "Universia"
# nombre = input("Ingrese nombre y apellido completo: ")
# edad = int(input("Cuantos años tiene? "))

PorcentajePorEdad = 0.0
PorcentajePorExamen = 0.0
PorcentajePorIngresos = 0.0 
DescuentoTotal = 0.0 

# Caso 1

edad = 23
puntaje = 100
ingreso = 12

if (edad >= 15 and edad <= 18):
    PorcentajePorEdad = 0.25 
elif (edad >= 19 and edad <= 21):
    PorcentajePorEdad = 0.15
elif (edad >= 22 and edad <= 25):
    PorcentajePorEdad = 0.10 
else:
    (edad <= 15 and edad >= 25)
    PorcentajePorEdad = 0.0
    
if (PuntajeExamen >= 80 and edad < 86):
    PorcentajePorExamen = 0.30 
elif (PuntajeExamen >= 80 and edad < 91):
    PorcentajePorExamen = 0.35
elif (PuntajeExamen >= 91 and edad <= 100):
    PorcentajePorExamen = 0.30 
else:
    (PuntajeExamen < 80)
    PorcentajePorExamen = 0.0
        
if (IngresoFamiliar <= 1.0):
    PorcentajePorIngresos = 0.30 
elif (IngresoFamiliar >= 1.0 and edad <= 2.0):
    PorcentajePorIngresos = 0.20
elif (IngresoFamiliar >= 2.0 and edad <= 3.0):
    PorcentajePorIngresos = 0.10 
elif (IngresoFamiliar >= 3.0 and edad <= 4.0):
    PorcentajePorIngresos = 0.10 
else:
    (IngresoFamiliar > 4.0)
    PorcentajePorIngresos = 0.0

DescuentoTotal = PorcentajePorEdad + PorcentajePorExamen + PorcentajePorIngresos

# Caso 2

edad = 21
puntaje = 100
ingreso = 5

PorcentajePorEdad = 0.0
PorcentajePorExamen = 0.0
PorcentajePorIngresos = 0.0 
DescuentoTotal = 0.0 

if (edad >= 15 and edad <= 18):
    PorcentajePorEdad = 0.25 
elif (edad >= 19 and edad <= 21):
    PorcentajePorEdad = 0.15
elif (edad >= 22 and edad <= 25):
    PorcentajePorEdad = 0.10 
else:
    (edad <= 15 and edad >= 25)
    PorcentajePorEdad = 0.0
    
if (PuntajeExamen >= 80 and edad < 86):
    PorcentajePorExamen = 0.30 
elif (PuntajeExamen >= 80 and edad < 91):
    PorcentajePorExamen = 0.35
elif (PuntajeExamen >= 91 and edad <= 100):
    PorcentajePorExamen = 0.30 
else:
    (PuntajeExamen < 80)
    PorcentajePorExamen = 0.0
        
if (IngresoFamiliar <= 1.0):
    PorcentajePorIngresos = 0.30 
elif (IngresoFamiliar >= 1.0 and edad <= 2.0):
    PorcentajePorIngresos = 0.20
elif (IngresoFamiliar >= 2.0 and edad <= 3.0):
    PorcentajePorIngresos = 0.10 
elif (IngresoFamiliar >= 3.0 and edad <= 4.0):
    PorcentajePorIngresos = 0.10 
else:
    (IngresoFamiliar > 4.0)
    PorcentajePorIngresos = 0.0

DescuentoTotal = PorcentajePorEdad + PorcentajePorExamen + PorcentaPorIngresos
# Caso 3

edad = 25
puntaje = 80
ingreso = 1

PorcentajePorEdad = 0.0
PorcentajePorExamen = 0.0
PorcentajePorIngresos = 0.0 
DescuentoTotal = 0.0

if (edad >= 15 and edad <= 18):
    PorcentajePorEdad = 0.25 
elif (edad >= 19 and edad <= 21):
    PorcentajePorEdad = 0.15
elif (edad >= 22 and edad <= 25):
    PorcentajePorEdad = 0.10 
else:
    (edad <= 15 and edad >= 25)
    PorcentajePorEdad = 0.0
    
if (PuntajeExamen >= 80 and edad < 86):
    PorcentajePorExamen = 0.30 
elif (PuntajeExamen >= 80 and edad < 91):
    PorcentajePorExamen = 0.35
elif (PuntajeExamen >= 91 and edad <= 100):
    PorcentajePorExamen = 0.30 
else:
    (PuntajeExamen < 80)
    PorcentajePorExamen = 0.0
        
if (IngresoFamiliar <= 1.0):
    PorcentajePorIngresos = 0.30 
elif (IngresoFamiliar >= 1.0 and edad <= 2.0):
    PorcentajePorIngresos = 0.20
elif (IngresoFamiliar >= 2.0 and edad <= 3.0):
    PorcentajePorIngresos = 0.10 
elif (IngresoFamiliar >= 3.0 and edad <= 4.0):
    PorcentajePorIngresos = 0.10 
else:
    (IngresoFamiliar > 4.0)
    PorcentajePorIngresos = 0.0

DescuentoTotal = PorcentajePorEdad + PorcentajePorExamen + PorcentaPorIngresos