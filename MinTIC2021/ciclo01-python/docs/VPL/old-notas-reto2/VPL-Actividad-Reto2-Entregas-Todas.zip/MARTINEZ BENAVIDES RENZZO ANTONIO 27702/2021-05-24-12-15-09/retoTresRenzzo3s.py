# Variables de entrada: Nombre(str), Apellido(str), edad(int), salario Minimo(float),
#examen de aptitud(float)
# Salidas: nombre, apellido, descuento por edad, descuento por ingreso familiar,
#descuento por examen, Descuento total(imprimir por pantalla).
#subsidios:
#descuento por edad: 15 a 18 = 25%, 19 a 21 = 15%, 22 a 25 = 10%, 25 años no tiene.
#descuento por ingreso familiar: <=1 : 30%,  > 1 and <= 2 : 20%, > 2 and <= 3: 10%, > 3 and <= 4: 5%, > 5: NO
#Por puntaje de ingreso: >= 80 and < 86: 35%, >= 91 and 96: 40%, >= 96: 45%, < 80: No Apoyo.
# % total de apollo  = edad + ingreso familliar + examen ingreso
#INICIALIZACION
#nombre = ""
#apellido = ""
notaExamen = 0
smlv = 1
descuentoTotal = 0
#print("***Bienvenido al sistema de beneficios para estudinates de la institucion***")
#
#PASO 1:Entradas
#nombre:str   = input("Ingrese su nombre seguido de la tecla ENTER por favor: ")
#apellido:str = input("Ingrese su apellido seguido de la tecla ENTER: ")
edad          = int(input("Ingrese su edad: "))
notaExamen    = int(input("Ingrese la calificacion del 0 a 100 seguido: "))
smlv          = int(input("Digite su ingreso mensual: "))
#PASO 2:Descuento por edad
if   edad in range(15, 19):
     edad = 25
#    print("Se aplica descuento de 25% por edad ")

elif edad in range(19,22):
     edad = 15
#    print("Se aplica descuento de 15% por edad ")

elif edad in range(22,26):
     edad = 10
#    print("Se aplica descuento de 10% por edad ")
    
else:
    edad > 25
    edad = 0
#    print("No tiene descuento por edad")

    
#PASO 3:Descuento por ingreso familiar
if (smlv <= 1):
    smlv = 30
elif (smlv >1 and smlv <= 2):
    smlv = 20
elif (smlv > 2 and smlv <= 3):
    smlv = 10
elif (smlv > 3 and smlv <= 4):
    smlv = 5
elif (smlv > 4):
    smlv = 0
    
#PASO 4: Descuento por promedio de notas
if (notaExamen >= 80 and notaExamen < 86):
    notaExamen = 30
#    print("Se aplica 30% de descuento por notas")
           
#
elif (notaExamen >= 86 and notaExamen < 91):
     notaExamen = 35
#    print("Se aplica 35% de descuento por notas")
#
elif (notaExamen >= 91 and notaExamen < 96):
     notaExamen = 40
#    print("Se aplica 40% de descuento por notas")
#
elif (notaExamen >= 96):
     notaExamen = 45

#    
else:
    (notaExamen < 80)
    notaExamen = 0
#        print("No tiene descuento por nota") 
#    print("Se aplica 45% de descuento por notas")
    
# PASO 5: Calculo de porcentaje desccuento total
#
descuentoTotal = edad + smlv + notaExamen
# 

#print("Estimado estudiante " , nombre , apellido, "usted a recibido un descuento total de: ", "\n", descuentoTotal, "%")
print(edad)
print(notaExamen)
print(smlv)
print(descuentoTotal)
#print("***Sobre el valor de la matricula***")


    
    
