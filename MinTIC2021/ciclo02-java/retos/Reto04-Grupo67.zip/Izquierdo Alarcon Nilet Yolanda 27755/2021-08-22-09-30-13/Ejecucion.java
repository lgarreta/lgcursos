//package main;

//import controller.EstudianteController;

public class Ejecucion {
    public static void main(String[] args){
        EstudianteController controller = new EstudianteController();
        controller.iniciar();
    }
}
