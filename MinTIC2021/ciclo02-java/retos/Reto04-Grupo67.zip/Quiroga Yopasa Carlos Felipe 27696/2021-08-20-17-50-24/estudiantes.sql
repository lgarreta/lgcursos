CREATE TABLE estudiantes (
    
    nombres             TEXT    ,
    apellidos           TEXT    ,
    fechadenacimiento   TEXT    ,
    correoInstitucional TEXT    NOT NULL,
    correoPersonal      TEXT    ,
    numeroCelular       INTEGER ,
    numeroTelefono      INTEGER ,
    programa            TEXT   
);
