//package Reto;

public class CPrograma {
    
    public static void main(String args[]) {
		CControlador controlador = new CControlador ();
		controlador.iniciar();
	}
    
    
}
