CREATE TABLE estudiantes (
	nombres TEXT,
	apellidos TEXT,
	fechaNacimiento TEXT,
	correoInstitucional TEXT NOT NULL,
	correoPersonal  TEXT,
	Celular INTEGER,
	telFijo INTEGER,
	programaAcademico TEXT);

