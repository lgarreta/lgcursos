CREATE TABLE estudiantes (
    nombres TEXT,
    apellidos TEXT,
    fechaNacimiento TEXT,
    correoInstitucional TEXT NOT NULL,
    correoPersonal TEXT,
    numeroroCelular INTEGER,
    numeroFijo INTEGER,
    programaAcademico TEXT
);
