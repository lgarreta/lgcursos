



// Clase que crea y ejecuta el controlador
public class ProgramaDirectorio {
    public static void main(String[] args) {
        Controlador ctrl = new Controlador ();
        ctrl.iniciar ();
    }
}

