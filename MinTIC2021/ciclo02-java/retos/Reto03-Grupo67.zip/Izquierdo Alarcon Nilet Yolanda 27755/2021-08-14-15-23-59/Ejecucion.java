//package main;

//import controller.EstudianteController;
import java.io.IOException;

public class Ejecucion {
    public static void main(String[] args) throws IOException {
        EstudianteController controller = new EstudianteController();
        controller.iniciar();
    }
}
