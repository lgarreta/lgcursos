public class ProgramaDirectorio {
	public static void main (String args []) {
		Controlador ctrl = new Controlador ();
		ctrl.iniciar ();
	}
}
