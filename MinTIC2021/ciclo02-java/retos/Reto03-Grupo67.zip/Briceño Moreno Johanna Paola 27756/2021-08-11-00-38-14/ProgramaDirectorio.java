
import java.io.IOException;


public class ProgramaDirectorio {
    public static void main(String[] args) throws IOException {
        Controlador ctrl = new Controlador ();
        ctrl.iniciar ();
    }
}

