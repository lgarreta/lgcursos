CREATE TABLE estudiantes (
    
    nombres TEXT,
    apellido TEXT,
    fecha TEXT,
    correoinstituto TEXT NOT NULL,
    correopersonal TEXT,
    celular INTEGER,
    fijo INTEGER,
    programa TEXT
);
