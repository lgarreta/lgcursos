public class Reto4 {

     public static void main(String[] args) {
    Controlador miControlador = new Controlador ();
        miControlador.ejecutar();
    }
}
