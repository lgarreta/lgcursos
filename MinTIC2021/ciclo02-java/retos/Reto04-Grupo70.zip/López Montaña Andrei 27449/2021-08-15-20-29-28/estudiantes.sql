CREATE TABLE "estudiantes" (
	id INTEGER NOT NULL PRIMARY KEY,
	"nombres"	TEXT,
	"apellidos"	TEXT NOT NULL,
	"fechanac"	TEXT NOT NULL,
	"correoinst"	TEXT NOT NULL,
	"correoper"	TEXT NOT NULL,
	"numcel"	INTEGER NOT NULL,
	"numfij"	INTEGER NOT NULL,
	"progaca"	TEXT NOT NULL
);