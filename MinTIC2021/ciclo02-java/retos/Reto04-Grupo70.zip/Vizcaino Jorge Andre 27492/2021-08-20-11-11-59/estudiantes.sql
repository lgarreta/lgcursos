CREATE TABLE estudiantes (
    Nombre TEXT,
    Apellido TEXT,
    FechaBirth TEXT,
    CorreoInst TEXT NOT NULL,
    correoPer TEXT,
    NroCelular INTEGER,
    NroFijo INTEGER,
    Programa TEXT
);