CREATE TABLE estudiantes (
    
    nombres TEXT,
    apellidos TEXT,
    fechaNacimiento TEXT,
    correoInstitucional TEXT NOT NULL,
    correoPersonal TEXT,
    numeroCelular INTEGER,
    numeroFijo INTEGER,
    programa TEXT
);

