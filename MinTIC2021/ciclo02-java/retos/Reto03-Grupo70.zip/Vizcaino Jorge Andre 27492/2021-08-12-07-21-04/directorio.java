
public class directorio {

	public static void main(String[] args) {
		Controlador ctrl = new Controlador();
		ctrl.iniciar();
	}
}
