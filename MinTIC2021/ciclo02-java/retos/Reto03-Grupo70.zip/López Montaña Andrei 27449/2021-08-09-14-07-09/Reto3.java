

public class Reto3 {

public static void main (String args[]){
        Controlador miControlador = new Controlador ();
        miControlador.ejecutar();
     }
    
}