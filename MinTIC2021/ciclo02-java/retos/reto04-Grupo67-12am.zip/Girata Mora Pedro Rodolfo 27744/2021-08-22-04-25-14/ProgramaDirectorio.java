public class ProgramaDirectorio {
    public static void main(String[] args) {
        Controlador Ctrl = new Controlador ();
        Ctrl.iniciar();
    }
}
