CREATE TABLE "estudiantes" (
	"nombre"	TEXT NOT NULL,
	"apellido"	TEXT NOT NULL,
	"fecha_nacimiento"	TEXT NOT NULL,
	"correo_institucional"	TEXT NOT NULL,
	"correo_personal"	TEXT NOT NULL,
	"numero_celular"	INTEGER NOT NULL,
	"numero_fijo"	INTEGER NOT NULL,
	"programa_academico"	TEXT NOT NULL
);