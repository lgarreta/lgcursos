CREATE TABLE estudiantes (
	id INTEGER NOT NULL PRIMARY KEY,
	nombres TEXT,
	apellidos TEXT,
	fechaNac TEXT,
	correoInst TEXT NOT NULL,
	correoPers  TEXT,
	nroCelular INTEGER,
	nroFijo INTEGER,
	program TEXT);

