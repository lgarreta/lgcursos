public class ProgramaEstudiantes{
    public static void main (String arg[]){
        Controlador miControlador = new Controlador();

        miControlador.iniciar();

        
    }
}