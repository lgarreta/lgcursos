
import java.io.IOException;

//import java.lang.NullPointerException;


public class ProgramaDirectorio {
    public static void main(String[] args) throws IOException {
        Controlador ctrl = new Controlador ();
        ctrl.iniciar ();
    }
}

