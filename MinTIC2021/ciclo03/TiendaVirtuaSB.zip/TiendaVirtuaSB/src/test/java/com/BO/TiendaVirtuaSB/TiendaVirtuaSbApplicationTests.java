package com.BO.TiendaVirtuaSB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaVirtuaSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
