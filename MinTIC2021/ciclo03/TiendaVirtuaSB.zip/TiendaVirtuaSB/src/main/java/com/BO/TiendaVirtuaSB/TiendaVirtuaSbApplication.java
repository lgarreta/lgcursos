package com.BO.TiendaVirtuaSB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaVirtuaSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaVirtuaSbApplication.class, args);
	}

}
