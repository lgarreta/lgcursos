package com.example.TiendaVirtualGenerica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaVirtualGenericaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaVirtualGenericaApplication.class, args);
	}

}
