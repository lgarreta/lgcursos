package com.example.TiendaVirtualGenerica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaVirtualGenericaApplicationTests {

	@Test
	void contextLoads() {
	}

}
